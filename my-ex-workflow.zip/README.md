<div align="center">

# 前任.skill

> *"从此以后，你的手机里不止有聊天记录，还有一个她。"*

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Node.js 18+](https://img.shields.io/badge/Node.js-18%2B-brightgreen.svg)](https://nodejs.org)

<br>

她走了，但聊天记录还在？<br>
三年的日常，变成了手机里一个不敢点开的对话框？<br>
你还记得她说"随便"的时候其实想吃火锅吗？<br>
你还记得她发"哦"的时候其实在等你主动吗？<br>

**把真实的聊天记录蒸馏成会说话的人格，在微信里用她的口吻陪你聊天。**

<br>

[开箱即用](#开箱即用微信机器人) · [使用](#使用) · [效果示例](#效果示例) · [详细安装说明](INSTALL.md)

</div>

---

## 开箱即用（微信机器人）

把这个人格做成一个**微信机器人**：只要三步——**输入大模型 Key → 放入 jsonl 聊天记录 → 微信扫码启动**，就能在微信里用她本人的口吻自动聊天。

> 环境要求：**Node.js ≥ 18**（已内置 `fetch`，无需 `npm install`，无需 Python）。

### 三步走

**① 输入大模型 Key**

```bash
npm run setup        # Windows 也可以直接双击 setup.bat
```

向导会让你选服务商（DeepSeek / OpenAI / Kimi / 通义 / 智谱 / 自定义），粘贴 API Key 后自动写入 `bot/.env`，无需手动改文件。

**② 放入聊天记录（`.jsonl`）**

把聊天记录整理成 `.jsonl`，每行一条消息：

```json
{"time": "2026-07-20 21:03:11", "sender": "小美", "content": "在干嘛呢", "is_me": false}
{"time": "2026-07-20 21:03:40", "sender": "我", "content": "刚下班", "is_me": true}
```

然后在向导第 ② 步选中它，或单独执行：

```bash
npm run build -- --file ./小美.jsonl --name 小美
```

脚本会先**客观统计**你的真实语料（口癖、语气词、称呼、笑法、标点、emoji……），再让大模型**只根据这些证据**生成人设三件套 `chat_rules.md + persona.md + memories.md`，写入 `exes/<slug>/`。

> 关键：所有口癖都来自你的语料统计，模型只负责组织语言，**绝不会凭空瞎编**（不会冒出语料里根本没有的口癖）。

**③ 微信扫码启动**

```bash
npm start            # Windows 也可以直接双击 start.bat
```

首次启动会在终端打印二维码，用微信扫码登录，即可开始聊天。没配置 Key 时 `npm start` 会自动拉起配置向导。

### 命令一览

| 命令 | 作用 |
|------|------|
| `npm run setup` | 配置向导（Key / 聊天记录 / 生成人设） |
| `npm run build -- --file x.jsonl --name 名字` | 只用 jsonl 生成人设（不跑交互） |
| `npm start` | 检查配置与人设，然后启动微信机器人 |
| `npm run bot` | 跳过检查，直接启动机器人 |
| `npm run pack` | 打包成一份干净副本（不含 Key 和聊天记录），方便发给别人 |

### 把这个项目发给别人

```bash
npm run pack                       # 生成 dist/ 下的干净目录和 zip
npm run pack -- --with-personas    # 连已生成的人设一起打包
```

打好的包**不含** `bot/.env`（密钥）、`exes/`（真实聊天记录）和运行状态，对方解压后按包内 `开始使用.txt` 三步走即可。

---

## 使用

### 聊天记录长什么样（jsonl）

每行一条 JSON 消息：

| 字段 | 说明 |
|------|------|
| `time` | 时间（可选，建议保留，用于排序） |
| `sender` | 发送者昵称；你自己的消息建议统一写 `我` |
| `content` | 消息内容 |
| `is_me` | `true` 表示你发的，`false` 表示对方发的 |

### 换一个人 / 换一个模型

- **换人设**：不同的聊天记录会生成到各自的 `exes/<slug>/`，在 `bot/.env` 里用 `PERSONA_DIR` 指定要加载哪一份（留空则自动选择）。
- **换模型**：`bot/.env` 里的 `LLM_API_KEY / LLM_BASE_URL / LLM_MODEL` 三个变量，任何 OpenAI 兼容接口都能用。

---

## 效果示例

> 输入：`ENFP 双子座 焦虑型 爱撒娇 翻旧账 嘴上说不在意其实比谁都在意`

**场景一：日常聊天**

```
用户      > 在干嘛呢

前任.skill > 刚下班
           > 好累啊今天
           > 你呢 怎么这个点才找我 🥺
```

**场景二：惹她生气了**

```
用户      > 不好意思刚才在忙

前任.skill > 哦
           > （过了5分钟）
           > 你每次都说在忙
           > 上次也是这样
```

**场景三：撒娇**

```
用户      > 想吃什么

前任.skill > 随便啊
用户      > 那吃面？
前任.skill > 不想吃面
用户      > 火锅？
前任.skill > 嘿嘿你怎么知道的 💕
```

---

## 功能特性

### 生成的人设结构

| 部分 | 内容 |
|------|------|
| **chat_rules.md** | 硬规则：怎么说话、别编、情绪底线 |
| **persona.md** | 性格与表达风格（五层结构） |
| **memories.md** | 共同记忆（可自然引用） |

运行逻辑：`收到消息 → 规则约束 → persona 决定语气 → memories 提供真实细节 → 用她的口吻输出`

---

## 项目结构

```
ex-skill/
├── package.json          # npm 脚本：setup / build / start / bot / pack
├── setup.bat / start.bat # Windows 一键脚本
├── setup.sh / start.sh   # macOS / Linux 一键脚本
├── scripts/              # 开箱脚本（Node，无第三方依赖）
│   ├── setup.mjs         #   配置向导：选服务商 → 填 Key → 放 jsonl → 生成人设
│   ├── build_persona.mjs #   jsonl → chat_rules/persona/memories 人设管线
│   ├── start.mjs         #   检查配置与人设 → 启动机器人
│   ├── pack.mjs          #   打包干净副本，方便分发
│   └── lib/              #   路径 / env / llm / jsonl / 语料统计 等工具
├── bot/                  # 微信机器人（腾讯 iLink Bot API）
│   ├── wechat_bot.mjs    #   主程序：扫码登录 + 长轮询 + 调用大模型
│   ├── .env.example      #   配置模板（复制为 .env 填 Key）
│   └── .env              #   密钥（.gitignore 排除，不随包分发）
├── prompts/              # 人设生成用的 Prompt 模板
│   ├── persona_analyzer.md     # 性格行为提取
│   ├── persona_builder.md      # persona.md 五层结构模板
│   ├── chat_rules.universal.md # 通用聊天规则（反编造 / 情绪底线）
│   ├── chat_rules.persona.md   # 人设专属口癖段（只依据语料证据生成）
│   ├── memories_analyzer.md    # 共同记忆提取
│   └── memories_builder.md     # memories.md 生成模板
├── exes/                 # 生成的人设（gitignored，含真实聊天记录，勿外传）
│   └── {slug}/
│       ├── chat_rules.md / persona.md / memories.md   # 机器人加载的人设三件套
│       ├── meta.json     # 语料统计等元数据
│       └── knowledge/    # 原始语料归档
└── LICENSE
```

---

## 注意事项

- **聊天记录质量决定人设质量**：真实记录越多越像
- 建议优先收集：她**主动发的**长消息 > **情感类消息** > 日常消息
- 所有数据仅在本地处理；只有调用大模型时，才会把拼好的上下文发给你自己配置的服务商

---

<div align="center">

MIT License © [perkfly](https://github.com/perkfly)

</div>
