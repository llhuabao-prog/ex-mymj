/**
 * 打包分发：把项目复制成一份「干净副本」，剔除密钥、运行状态和真实聊天记录，
 * 然后压缩成 zip，方便直接发给别人。
 *
 *   npm run pack              # 生成 dist/ex-wechat-bot/ 和 dist/ex-wechat-bot.zip
 *   npm run pack -- --with-personas   # 连 exes/ 下已生成的人设一起打包
 *   npm run pack -- --name my-bot     # 自定义包名
 *
 * 默认剔除（防止泄露隐私/密钥）：
 *   bot/.env、bot/.state/、*.log、exes 下的真实人设与聊天记录、node_modules、dist、.git
 */
import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";

import { ROOT } from "./lib/paths.mjs";

const args = process.argv.slice(2);
const withPersonas = args.includes("--with-personas");
const nameIdx = args.indexOf("--name");
const PKG_NAME =
  (nameIdx >= 0 && args[nameIdx + 1]) || path.basename(ROOT).replace(/[^\w.-]+/g, "-") || "ex-wechat-bot";

const DIST = path.join(ROOT, "dist");
const TARGET = path.join(DIST, PKG_NAME);

// 永远剔除的东西
const ALWAYS_EXCLUDE = new Set([
  ".git",
  "node_modules",
  "dist",
  "__pycache__",
  ".venv",
  "venv",
  "bot/.state",
]);
const ALWAYS_EXCLUDE_FILES = new Set(["bot/.env"]);
const LOG_RE = /\.log$/;
const ZIP_RE = /\.(zip|tar\.gz)$/;

function relIsExcluded(rel) {
  const norm = rel.split(path.sep).join("/");
  if (ALWAYS_EXCLUDE.has(norm)) return true;
  for (const ex of ALWAYS_EXCLUDE) {
    if (norm === ex || norm.startsWith(ex + "/")) return true;
  }
  if (ALWAYS_EXCLUDE_FILES.has(norm)) return true;
  if (LOG_RE.test(norm) || ZIP_RE.test(norm)) return true;
  // 真实人设（含聊天记录）默认不打包
  if (!withPersonas && norm.startsWith("exes/") && norm !== "exes" && norm.split("/")[1]) {
    return true;
  }
  return false;
}

function copyTree(src, dest, root = src) {
  fs.mkdirSync(dest, { recursive: true });
  for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
    const s = path.join(src, entry.name);
    const d = path.join(dest, entry.name);
    const rel = path.relative(root, s);
    if (relIsExcluded(rel)) {
      console.log("  跳过 " + rel.split(path.sep).join("/"));
      continue;
    }
    if (entry.isDirectory()) copyTree(s, d, root);
    else if (entry.isFile()) fs.copyFileSync(s, d);
  }
}

function zip(srcDir, outFileNoExt) {
  const isWin = process.platform === "win32";
  if (isWin) {
    const r = spawnSync(
      "powershell",
      ["-NoProfile", "-Command", `Compress-Archive -Path '${srcDir}\\*' -DestinationPath '${outFileNoExt}.zip' -Force`],
      { stdio: "inherit" },
    );
    return r.status === 0 ? outFileNoExt + ".zip" : "";
  }
  const r = spawnSync("zip", ["-rq", outFileNoExt + ".zip", "."], { cwd: srcDir, stdio: "inherit" });
  return r.status === 0 ? outFileNoExt + ".zip" : "";
}

console.log(`\n打包项目 → dist/${PKG_NAME}/`);
console.log(withPersonas ? "（包含 exes/ 人设）" : "（不含 exes/ 人设与 bot/.env，安全分发）");

fs.rmSync(TARGET, { recursive: true, force: true });
copyTree(ROOT, TARGET);

// 附带一份「拿到先看这里」
fs.writeFileSync(
  path.join(TARGET, "开始使用.txt"),
  `这是一个微信 AI 人格机器人。三步就能用：

1) 安装 Node.js 18+（https://nodejs.org）
2) 打开终端进入本目录，执行：npm run setup
   （Windows 也可以直接双击 setup.bat）
   按提示：填大模型 Key → 选择你的聊天记录 jsonl → 自动生成人设
3) 执行：npm start   （Windows 双击 start.bat）
   终端出现二维码后，用微信扫码登录，即可开始聊天。

详细说明见 README.md / INSTALL.md。
注意：本压缩包不含任何密钥和别人的聊天记录，请放心使用。
`,
  "utf-8",
);

const zipPath = zip(TARGET, path.join(DIST, PKG_NAME));
console.log(`\n✅ 完成`);
console.log(`   目录：dist/${PKG_NAME}/`);
if (zipPath) console.log(`   压缩包：${path.relative(ROOT, zipPath)}`);
else console.log("   （未生成 zip：系统缺少 zip / Compress-Archive，可直接转发 dist 下的目录）");
