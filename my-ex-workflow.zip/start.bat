@echo off
chcp 65001 >nul
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo   [错误] 没有检测到 Node.js。
  echo   请先到 https://nodejs.org 下载安装 LTS 版本，然后重新双击本文件。
  echo.
  pause
  exit /b 1
)

echo.
echo   正在启动前任微信机器人...
echo.
node scripts\start.mjs
echo.
pause
