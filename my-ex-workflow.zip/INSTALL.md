# 前任.skill 安装说明

---

## 微信机器人（开箱即用，推荐）

只想让机器人跑起来、在微信里聊天？**三步就够了**，不需要装 Python。

**前置条件**：装好 [Node.js ≥ 18](https://nodejs.org)（`node -v` 能打印版本即可）。

### ① 输入大模型 Key

```bash
npm run setup
```

- Windows 用户也可以直接**双击 `setup.bat`**。
- macOS / Linux 也可以 `bash setup.sh`，或直接跑上面的命令。
- 向导会让你选服务商（DeepSeek / OpenAI / Kimi / 通义 / 智谱 / 自定义），粘贴 API Key 后自动写入 `bot/.env`。

> 也可以手动复制 `bot/.env.example` 为 `bot/.env`，把 `LLM_API_KEY` 填上即可。

### ② 放入聊天记录（`.jsonl`）

- 把聊天记录整理成 `.jsonl`，**每行一条**消息：

```json
{"time": "2026-07-20 21:03:11", "sender": "小美", "content": "在干嘛呢", "is_me": false}
{"time": "2026-07-20 21:03:40", "sender": "我", "content": "刚下班", "is_me": true}
```

- `is_me: true` 表示这条是你发的，`false` 表示是对方发的（两种人的消息都会用到）。
- 在向导第 ② 步选中这个文件；也可以跳过向导，单独生成：

```bash
npm run build -- --file ./小美.jsonl --name 小美
```

生成结果在 `exes/<slug>/`，包含 `chat_rules.md`、`persona.md`、`memories.md`（机器人启动时自动加载）。

### ③ 微信扫码启动

```bash
npm start
```

- Windows 也可以直接**双击 `start.bat`**。
- 首次启动终端会打印二维码，用**微信扫码登录**，然后就会自动回复消息了。
- 没配置 Key 时 `npm start` 会自动先拉起配置向导。

---

## 配置项（`bot/.env`）

| 变量 | 说明 |
|------|------|
| `LLM_API_KEY` | 大模型 API Key（必填） |
| `LLM_BASE_URL` | 接口地址，默认 `https://api.deepseek.com` |
| `LLM_MODEL` | 模型名，默认 `deepseek-chat` |
| `PERSONA_DIR` | 指定要加载哪份人设（如 `./exes/小美`），留空自动选择 |

任何 OpenAI 兼容服务都行：

| 服务商 | `LLM_BASE_URL` | `LLM_MODEL` |
|--------|----------------|-------------|
| DeepSeek | `https://api.deepseek.com` | `deepseek-chat` |
| OpenAI | `https://api.openai.com/v1` | `gpt-4o-mini` |
| Kimi | `https://api.moonshot.cn/v1` | `moonshot-v1-8k` |
| 通义千问 | `https://dashscope.aliyuncs.com/compatible-mode/v1` | `qwen-plus` |
| 智谱 GLM | `https://open.bigmodel.cn/api/paas/v4` | `glm-4-flash` |

---

## 聊天记录怎么准备成 jsonl

机器人读取的是一行一条消息的 `.jsonl`，字段说明：

| 字段 | 说明 |
|------|------|
| `time` | 时间，格式 `YYYY-MM-DD HH:mm:ss`（可选，但建议保留以便排序） |
| `sender` | 发送者昵称；你自己的消息统一写 `我` |
| `content` | 消息内容 |
| `is_me` | `true` 表示你发的，`false` 表示对方发的 |

微信聊天记录可用 [WechatExporter](https://github.com/nicktang1990/WechatExporter) 等工具导出为 txt/csv，再整理成上面的 jsonl 格式即可。

---

## 常见问题

- **终端没有二维码**：确认终端窗口足够大、日志没有把它冲掉；重新 `npm start` 即可。
- **回复报错 / 401**：检查 `bot/.env` 里的 `LLM_API_KEY`、`LLM_BASE_URL`、`LLM_MODEL` 是否与你选的服务商匹配。
- **人设不像她**：多喂一些她**本人发的**聊天记录，然后重新执行 `npm run build`。
- **想发给别人**：执行 `npm run pack`，会在 `dist/` 下生成不含密钥和聊天记录的干净副本与 zip。

---

## 目录结构说明

```
ex-skill/
├── package.json          # npm 脚本：setup / build / start / bot / pack
├── scripts/              # 开箱脚本（setup / build / start / pack）
├── bot/                  # 微信机器人（.env 是你的密钥，不随包分发）
├── prompts/              # 人设生成用的 Prompt 模板
├── setup.bat / start.bat # Windows 一键脚本
├── setup.sh / start.sh   # macOS / Linux 一键脚本
└── exes/                 # 生成的人设（.gitignore 排除，含真实记录勿外传）
    └── {slug}/
        ├── chat_rules.md   # 说话规则
        ├── persona.md      # 性格与表达风格
        ├── memories.md     # 共同记忆
        ├── meta.json       # 元数据
        └── knowledge/      # 原始语料归档
```
