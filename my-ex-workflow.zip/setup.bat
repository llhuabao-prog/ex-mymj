@echo off
chcp 65001 >nul
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo   [错误] 没有检测到 Node.js。请先到 https://nodejs.org 安装 LTS 版本。
  echo.
  pause
  exit /b 1
)

node scripts\setup.mjs
echo.
pause
