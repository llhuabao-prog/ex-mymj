#!/usr/bin/env node
/**
 * 微信机器人桥接
 * 官方 ClawBot iLink API <-> 任意 OpenAI 兼容大模型（DeepSeek / OpenAI / 通义 / 智谱…）
 *
 * 流程：
 *   1. 扫码登录：ilink/bot/get_bot_qrcode + get_qrcode_status
 *   2. 长轮询收消息：ilink/bot/getupdates
 *   3. 调大模型（系统提示词 = exes/<人设> 下的 chat_rules + persona + memories）
 *   4. 发回微信：ilink/bot/sendmessage
 *
 * 配置见 bot/.env（可先跑 `npm run setup` 一键生成）
 */
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const log = (m) => process.stderr.write(`[bot] ${m}\n`);
const logErr = (m) => process.stderr.write(`[bot][ERROR] ${m}\n`);

// ── 配置 ────────────────────────────────────────────────────────────────────
const BASE_URL = process.env.WECHAT_ILINK_BASE || "https://ilinkai.weixin.qq.com";
const BOT_TYPE = "3";
const CHANNEL_VERSION = "2.4.9";
const BOT_AGENT = "OpenClaw";
const ILINK_APP_ID = "bot";
const ILINK_APP_CLIENT_VERSION = "132105"; // (2<<16)|(4<<8)|9 —— 对应 2.4.9
const LONG_POLL_TIMEOUT_MS = 35000;
const MAX_FAILURES = 3;
const BACKOFF_MS = 30000;
const RETRY_MS = 2000;

// 大模型配置（通用变量 LLM_* 优先，兼容旧的 DEEPSEEK_*）
const LLM_KEY = process.env.LLM_API_KEY || process.env.DEEPSEEK_API_KEY || "";
const LLM_BASE = process.env.LLM_BASE_URL || process.env.DEEPSEEK_BASE_URL || "https://api.deepseek.com";
const LLM_MODEL = process.env.LLM_MODEL || process.env.DEEPSEEK_MODEL || "deepseek-chat";

const STATE_DIR = process.env.STATE_DIR || path.join(__dirname, ".state");
const ACCOUNT_FILE = path.join(STATE_DIR, "account.json");
const SYNC_BUF_FILE = path.join(STATE_DIR, "sync_buf.txt");
const QR_FILE = path.join(STATE_DIR, "qr.txt");

/**
 * 解析人设目录：优先 PERSONA_DIR 环境变量；否则自动扫描 ../exes/ 下第一个含
 * chat_rules.md / persona.md 的目录（方便"换个 jsonl 生成一份新的人设"。
 */
function resolvePersonaDir() {
  if (process.env.PERSONA_DIR && process.env.PERSONA_DIR.trim()) {
    return process.env.PERSONA_DIR.trim();
  }
  const exesDir = path.join(__dirname, "..", "exes");
  try {
    const dirs = fs
      .readdirSync(exesDir, { withFileTypes: true })
      .filter((d) => d.isDirectory())
      .map((d) => path.join(exesDir, d.name))
      .filter(
        (d) =>
          fs.existsSync(path.join(d, "chat_rules.md")) ||
          fs.existsSync(path.join(d, "persona.md")),
      );
    if (dirs.length === 1) return dirs[0];
    if (dirs.length > 1) {
      // 多个时优先含 chat_rules.md 的，其次按名称排序取第一个
      const withRules = dirs.filter((d) => fs.existsSync(path.join(d, "chat_rules.md")));
      const pick = (withRules.length ? withRules : dirs).sort()[0];
      log(`检测到 ${dirs.length} 份人设，自动选用：${path.basename(pick)}（可用 PERSONA_DIR 指定）`);
      return pick;
    }
  } catch {}
  return path.join(exesDir, "persona");
}
const PERSONA_DIR = resolvePersonaDir();

const MSG_TYPE_USER = 1;
const MSG_TYPE_BOT = 2;
const MSG_STATE_FINISH = 2;
const MSG_ITEM_TEXT = 1;

// ── 工具函数 ────────────────────────────────────────────────────────────────
function randomWechatUin() {
  const uint32 = crypto.randomBytes(4).readUInt32BE(0);
  return Buffer.from(String(uint32), "utf-8").toString("base64");
}

function baseInfo() {
  return { channel_version: CHANNEL_VERSION, bot_agent: BOT_AGENT };
}

function buildHeaders(token, body) {
  const h = {
    "Content-Type": "application/json",
    AuthorizationType: "ilink_bot_token",
    "X-WECHAT-UIN": randomWechatUin(),
    "iLink-App-Id": ILINK_APP_ID,
    "iLink-App-ClientVersion": ILINK_APP_CLIENT_VERSION,
  };
  if (token && token.trim()) h.Authorization = `Bearer ${token.trim()}`;
  return h;
}

async function apiFetch(baseUrl, endpoint, body, token, timeoutMs) {
  const base = baseUrl.endsWith("/") ? baseUrl : `${baseUrl}/`;
  const url = new URL(endpoint, base).toString();
  const headers = buildHeaders(token, body);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { method: "POST", headers, body, signal: controller.signal });
    clearTimeout(timer);
    const text = await res.text();
    if (!res.ok) throw new Error(`HTTP ${res.status}: ${text}`);
    return text;
  } catch (e) {
    clearTimeout(timer);
    throw e;
  }
}

// ── 扫码登录 ────────────────────────────────────────────────────────────────
async function fetchQRCode(baseUrl) {
  const base = baseUrl.endsWith("/") ? baseUrl : `${baseUrl}/`;
  const url = new URL(`ilink/bot/get_bot_qrcode?bot_type=${encodeURIComponent(BOT_TYPE)}`, base).toString();
  const res = await fetch(url);
  if (!res.ok) throw new Error(`QR fetch failed: ${res.status}`);
  return res.json(); // { qrcode, qrcode_img_content }
}

async function pollQRStatus(baseUrl, qrcode) {
  const base = baseUrl.endsWith("/") ? baseUrl : `${baseUrl}/`;
  const url = new URL(`ilink/bot/get_qrcode_status?qrcode=${encodeURIComponent(qrcode)}`, base).toString();
  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), 35000);
  try {
    const res = await fetch(url, { headers: { "iLink-App-ClientVersion": "1" }, signal: controller.signal });
    clearTimeout(t);
    if (!res.ok) throw new Error(`QR status failed: ${res.status}`);
    return res.json();
  } catch (e) {
    clearTimeout(t);
    if (e.name === "AbortError") return { status: "wait" };
    throw e;
  }
}

async function doQRLogin(baseUrl) {
  log("获取微信登录二维码...");
  const qr = await fetchQRCode(baseUrl);
  fs.mkdirSync(STATE_DIR, { recursive: true });
  fs.writeFileSync(QR_FILE, qr.qrcode_img_content, "utf-8");
  log(`扫码链接（已写入 ${QR_FILE}）：`);
  log(`${qr.qrcode_img_content}`);
  log("等待扫码确认...");
  const deadline = Date.now() + 480000;
  let scanned = false;
  while (Date.now() < deadline) {
    const s = await pollQRStatus(baseUrl, qr.qrcode);
    if (s.status === "scaned" && !scanned) {
      log("已扫码，请在手机上确认...");
      scanned = true;
    } else if (s.status === "expired") {
      log("二维码已过期，请重新运行。");
      return null;
    } else if (s.status === "confirmed") {
      if (!s.ilink_bot_id || !s.bot_token) {
        logErr("登录确认但未返回 bot 信息");
        return null;
      }
      const account = {
        token: s.bot_token,
        baseUrl: s.baseurl || baseUrl,
        accountId: s.ilink_bot_id,
        userId: s.ilink_user_id,
        savedAt: new Date().toISOString(),
      };
      fs.mkdirSync(STATE_DIR, { recursive: true });
      fs.writeFileSync(ACCOUNT_FILE, JSON.stringify(account, null, 2), "utf-8");
      log("微信连接成功！");
      return account;
    }
    await new Promise((r) => setTimeout(r, 1000));
  }
  log("登录超时");
  return null;
}

// ── 消息收发 ────────────────────────────────────────────────────────────────
async function getUpdates(baseUrl, token, buf) {
  try {
    const raw = await apiFetch(
      baseUrl,
      "ilink/bot/getupdates",
      JSON.stringify({ get_updates_buf: buf, base_info: baseInfo() }),
      token,
      LONG_POLL_TIMEOUT_MS,
    );
    return JSON.parse(raw);
  } catch (e) {
    if (e.name === "AbortError") return { ret: 0, msgs: [], get_updates_buf: buf };
    throw e;
  }
}

function clientId() {
  return `openclaw-weixin:${Date.now()}-${crypto.randomBytes(4).toString("hex")}`;
}

async function sendText(baseUrl, token, to, text, contextToken) {
  const raw = await apiFetch(
    baseUrl,
    "ilink/bot/sendmessage",
    JSON.stringify({
      msg: {
        from_user_id: "",
        to_user_id: to,
        client_id: clientId(),
        message_type: MSG_TYPE_BOT,
        message_state: MSG_STATE_FINISH,
        item_list: [{ type: MSG_ITEM_TEXT, text_item: { text } }],
        context_token: contextToken,
      },
      base_info: baseInfo(),
    }),
    token,
    15000,
  );
  log(`sendmessage 响应: ${raw.slice(0, 300)}`);
  try {
    const r = JSON.parse(raw);
    if (r && r.ret !== undefined && r.ret !== 0) {
      throw new Error(`sendmessage 被拒: ret=${r.ret} errmsg=${r.errmsg ?? ""}`);
    }
  } catch (e) {
    if (String(e).includes("sendmessage 被拒")) throw e;
    // 非 JSON 响应忽略
  }
}

function extractText(msg) {
  if (!msg.item_list || !msg.item_list.length) return null;
  for (const item of msg.item_list) {
    if (item.type === MSG_ITEM_TEXT && item.text_item && item.text_item.text) {
      return item.text_item.text;
    }
    if (item.type === 3 && item.voice_item && item.voice_item.text) {
      return `[语音转文字] ${item.voice_item.text}`;
    }
    if (item.type === 2) return "[图片]";
    if (item.type === 4) return "[文件]";
  }
  return null;
}

// ── 大模型调用 ───────────────────────────────────────────────────────────────
function readIfExists(p) {
  try {
    return fs.readFileSync(p, "utf-8");
  } catch {
    return "";
  }
}

let _personaCache = null;
function loadPersona() {
  if (_personaCache !== null) return _personaCache;
  const rules = readIfExists(path.join(PERSONA_DIR, "chat_rules.md"));
  const persona = readIfExists(path.join(PERSONA_DIR, "persona.md"));
  const memories = readIfExists(path.join(PERSONA_DIR, "memories.md"));
  if (!rules && !persona && !memories) {
    logErr(`无法读取 persona 文件（${PERSONA_DIR}），使用内置默认人设`);
    logErr("建议：先在 exes/ 下生成人设（运行 npm run setup 或 jsonl 生成管线）");
    _personaCache =
      "你正在微信里和对方聊天。说话短、碎、口语化，多用语气词和 emoji，" +
      "像真人一样随口接话，绝不承认自己是 AI。";
    return _personaCache;
  }
  const parts = [];
  if (rules) parts.push(rules.trim());
  if (persona) parts.push("===== 你的人格设定（背景：用来判断你会怎么想、怎么说） =====\n" + persona.trim());
  if (memories) parts.push("===== 你们的共同记忆（聊天时可自然引用，别生硬罗列） =====\n" + memories.trim());
  _personaCache = parts.join("\n\n");
  return _personaCache;
}

async function llmReply(history) {
  const messages = [{ role: "system", content: loadPersona() }, ...history];
  const res = await fetch(`${LLM_BASE}/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${LLM_KEY}`,
    },
    body: JSON.stringify({
      model: LLM_MODEL,
      messages,
      temperature: 1.0,
      presence_penalty: 0.3,
      frequency_penalty: 0.3,
      max_tokens: 800,
      stream: false,
    }),
  });
  if (!res.ok) {
    const t = await res.text();
    throw new Error(`LLM HTTP ${res.status}: ${t.slice(0, 300)}`);
  }
  const data = await res.json();
  return (data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content || "").trim();
}

// ── 会话历史（按会话 key 记忆）────────────────────────────────────────────
const history = new Map();

function pushHistory(key, role, content) {
  if (!history.has(key)) history.set(key, []);
  const h = history.get(key);
  h.push({ role, content });
  if (h.length > 24) h.splice(0, h.length - 24);
}

// ── 主轮询循环 ──────────────────────────────────────────────────────────────
async function startPolling(account) {
  const { baseUrl, token } = account;
  let buf = "";
  try {
    if (fs.existsSync(SYNC_BUF_FILE)) buf = fs.readFileSync(SYNC_BUF_FILE, "utf-8");
  } catch {}
  const contextCache = new Map();
  log("开始监听微信消息...");
  let failures = 0;

  while (true) {
    try {
      const resp = await getUpdates(baseUrl, token, buf);
      const isErr =
        (resp.ret !== undefined && resp.ret !== 0) ||
        (resp.errcode !== undefined && resp.errcode !== 0);
      if (isErr) {
        failures++;
        logErr(`getUpdates 失败 ret=${resp.ret} errcode=${resp.errcode} errmsg=${resp.errmsg ?? ""}`);
        const wait = failures >= MAX_FAILURES ? BACKOFF_MS : RETRY_MS;
        if (failures >= MAX_FAILURES) failures = 0;
        await new Promise((r) => setTimeout(r, wait));
        continue;
      }
      failures = 0;

      if (resp.get_updates_buf) {
        buf = resp.get_updates_buf;
        try { fs.writeFileSync(SYNC_BUF_FILE, buf, "utf-8"); } catch {}
      }

      if ((resp.msgs ?? []).length) {
        try {
          fs.writeFileSync(
            path.join(STATE_DIR, "last_updates.json"),
            JSON.stringify(resp, null, 2),
            "utf-8",
          );
        } catch {}
      }

      for (const msg of resp.msgs ?? []) {
        if (msg.message_type !== MSG_TYPE_USER) {
          log(`[跳过] 非用户消息 message_type=${msg.message_type} item_types=${(msg.item_list ?? []).map((i) => i.type).join(",")}`);
          continue;
        }
        const text = extractText(msg);
        if (!text) {
          log(`[跳过] 无法提取文本 item_types=${(msg.item_list ?? []).map((i) => i.type).join(",")} from=${msg.from_user_id ?? "?"}`);
          continue;
        }

        const senderId = (msg.from_user_id ?? "").trim() || "unknown";
        const groupId = (msg.group_id ?? "").trim();
        const key = groupId || senderId;
        const to = groupId || senderId;
        if (msg.context_token) contextCache.set(key, msg.context_token);
        const ctx = msg.context_token || contextCache.get(key);

        log(`收到${groupId ? "群" : "私"}消息: ${text.slice(0, 50)}`);
        log(`  from=${senderId} to=${msg.to_user_id ?? "?"} ctx=${(ctx ?? "").slice(0, 20)}...`);
        if (!ctx) {
          logErr("缺少 context_token，无法回复，跳过");
          continue;
        }
        try {
          pushHistory(key, "user", text);
          const reply = await llmReply(history.get(key));
          if (!reply) continue;
          const lines = reply.split(/\n+/).filter(Boolean).slice(0, 8);
          for (const line of lines) {
            await sendText(baseUrl, token, to, line, ctx);
            await new Promise((r) => setTimeout(r, 400));
          }
          pushHistory(key, "assistant", reply);
          log(`已回复: ${reply.slice(0, 50)}`);
        } catch (e) {
          logErr(`回复失败: ${String(e)}`);
        }
      }
    } catch (e) {
      failures++;
      logErr(`轮询异常: ${String(e)}`);
      const wait = failures >= MAX_FAILURES ? BACKOFF_MS : RETRY_MS;
      if (failures >= MAX_FAILURES) failures = 0;
      await new Promise((r) => setTimeout(r, wait));
    }
  }
}

// ── 入口 ─────────────────────────────────────────────────────────────────────
async function main() {
  const forceSetup = process.argv.includes("--setup");
  if (!LLM_KEY) {
    logErr("缺少大模型 Key：请在 bot/.env 中配置 LLM_API_KEY（或运行 npm run setup 走一键向导）");
    process.exit(1);
  }
  let account = null;
  try {
    account = JSON.parse(fs.readFileSync(ACCOUNT_FILE, "utf-8"));
  } catch {}

  if (!account || forceSetup) {
    log("启动扫码登录...");
    account = await doQRLogin(BASE_URL);
    if (!account) process.exit(1);
  } else {
    log(`使用已保存账号: ${account.accountId}`);
  }
  await startPolling(account);
}

main().catch((e) => {
  logErr(String(e));
  process.exit(1);
});
