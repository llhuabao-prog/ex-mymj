/**
 * 一键配置向导：填 key -> （可选）放 jsonl 生成人设 -> 写好 .env。
 *
 *   npm run setup
 */
import fs from "node:fs";
import path from "node:path";
import readline from "node:readline/promises";
import { stdin as input, stdout as output } from "node:process";

import { ENV_FILE } from "./lib/paths.mjs";
import { loadEnv, writeEnv, parseEnv, PROVIDERS } from "./lib/env.mjs";
import { buildPersona } from "./build_persona.mjs";

const C = {
  b: (s) => `\x1b[1m${s}\x1b[0m`,
  g: (s) => `\x1b[32m${s}\x1b[0m`,
  y: (s) => `\x1b[33m${s}\x1b[0m`,
  c: (s) => `\x1b[36m${s}\x1b[0m`,
  r: (s) => `\x1b[31m${s}\x1b[0m`,
  d: (s) => `\x1b[2m${s}\x1b[0m`,
};

function banner() {
  console.log("");
  console.log(C.b("  💬  前任微信机器人 · 一键配置"));
  console.log(C.d("  放聊天记录 → 扫码 → 填 key，三步就能用"));
  console.log("");
}

async function ask(rl, q, def = "") {
  const suffix = def ? C.d(`（默认 ${def}，直接回车即可）`) : "";
  const a = (await rl.question(`${q}${suffix}\n> `)).trim();
  return a || def;
}

async function askRequired(rl, q) {
  for (;;) {
    const a = (await rl.question(`${q}\n> `)).trim();
    if (a) return a;
    console.log(C.r("  这一项不能为空，请重新输入。"));
  }
}

async function main() {
  banner();
  const rl = readline.createInterface({ input, output });

  try {
    // 1) 是否已有配置
    let existing = {};
    if (fs.existsSync(ENV_FILE)) {
      existing = parseEnv(fs.readFileSync(ENV_FILE, "utf-8"));
      if (existing.LLM_API_KEY || existing.DEEPSEEK_API_KEY) {
        console.log(C.y("  检测到已存在 bot/.env 配置。"));
        const again = await ask(rl, "  要重新配置吗？(y/N)", "N");
        if (!/^y(es)?$/i.test(again)) {
          console.log(C.d("  保留原配置。"));
        } else {
          existing = {};
        }
      }
    }

    const cfg = { LLM_API_KEY: existing.LLM_API_KEY || "", LLM_BASE_URL: "", LLM_MODEL: "" };

    if (!cfg.LLM_API_KEY) {
      console.log("");
      console.log(C.b("  第 1 步 · 选大模型服务商"));
      PROVIDERS.forEach((p, i) => console.log(`    ${i + 1}. ${p.label}`));
      const pick = await ask(rl, "  输入序号", "1");
      const idx = Math.max(1, Math.min(PROVIDERS.length, parseInt(pick, 10) || 1)) - 1;
      const prov = PROVIDERS[idx];

      if (prov.keyUrl) {
        console.log(C.d(`  去这里申请 Key：${prov.keyUrl}`));
      }
      cfg.LLM_API_KEY = await askRequired(rl, "  粘贴你的 API Key");

      if (prov.id === "custom") {
        cfg.LLM_BASE_URL = await askRequired(
          rl,
          "  Base URL（例如 https://api.deepseek.com 或带 /v1 的中转地址）",
        );
        cfg.LLM_MODEL = await askRequired(rl, "  模型名（例如 gpt-4o-mini / deepseek-chat）");
      } else {
        cfg.LLM_BASE_URL = await ask(rl, "  Base URL", prov.base);
        cfg.LLM_MODEL = await ask(rl, "  模型名", prov.model);
      }
    } else {
      cfg.LLM_BASE_URL = existing.LLM_BASE_URL || "https://api.deepseek.com";
      cfg.LLM_MODEL = existing.LLM_MODEL || "deepseek-chat";
    }

    // 写入 .env，并注入当前进程，保证后面生成人设时能直接调用
    writeEnv(
      ENV_FILE,
      {
        LLM_API_KEY: cfg.LLM_API_KEY,
        LLM_BASE_URL: cfg.LLM_BASE_URL,
        LLM_MODEL: cfg.LLM_MODEL,
      },
      {
        header:
          "前任微信机器人大模型配置\n" +
          "LLM_* 为通用变量，任何 OpenAI 兼容服务都适用\n" +
          "此文件包含密钥，请勿提交到 git / 分享给别人",
      },
    );
    process.env.LLM_API_KEY = cfg.LLM_API_KEY;
    process.env.LLM_BASE_URL = cfg.LLM_BASE_URL;
    process.env.LLM_MODEL = cfg.LLM_MODEL;
    console.log(C.g(`  ✓ 已写入 bot/.env（模型：${cfg.LLM_MODEL}）`));

    // 2) 生成人设
    console.log("");
    console.log(C.b("  第 2 步 · 用聊天记录生成人设"));
    console.log(C.d("  需要一份 jsonl 聊天记录，每行一个 JSON，例如："));
    console.log(
      C.d('  {"time":"2026-10-03 12:35:21","sender":"我","content":"好诺","is_me":true}'),
    );
    const jf = (await rl.question("\n  聊天记录 jsonl 文件路径（没有就回车跳过）\n> ")).trim();

    if (jf) {
      const abs = path.resolve(jf.replace(/^["']|["']$/g, ""));
      if (!fs.existsSync(abs)) {
        console.log(C.r(`  ✗ 找不到文件：${abs}，已跳过生成。可稍后运行 npm run build。`));
      } else {
        const name = await ask(rl, "  她的昵称/代号（用于称呼与人设名）", "");
        const profile = await ask(
          rl,
          "  一句话基本情况（在一起多久、怎么认识、她做什么的，可跳过）",
          "",
        );
        const tags = await ask(
          rl,
          "  一句话性格（MBTI/星座/依恋类型/恋爱特点，可跳过）",
          "",
        );
        console.log("");
        try {
          const r = await buildPersona({
            file: abs,
            name: name || undefined,
            profile: profile || undefined,
            tags: tags || undefined,
            emit: (m) => console.log(C.d("  " + m)),
          });
          console.log(C.g(`  ✓ 人设已生成：exes/${r.slug}/`));
        } catch (e) {
          console.log(C.r(`  ✗ 生成失败：${e.message}`));
          console.log(C.d("  可稍后重试：npm run build -- --file " + abs));
        }
      }
    } else {
      console.log(C.d("  已跳过。稍后可运行：npm run build -- --file 你的.jsonl"));
    }

    // 3) 收尾
    console.log("");
    console.log(C.b("  第 3 步 · 启动"));
    console.log(C.d("  运行下面任意一条，会弹出二维码，用微信扫码即可："));
    console.log(C.g("    npm start          # 或双击 start.bat"));
    console.log("");
  } finally {
    rl.close();
  }
}

main().catch((e) => {
  console.error(C.r("配置向导出错：" + e.message));
  process.exit(1);
});
