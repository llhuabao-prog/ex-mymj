#!/usr/bin/env bash
# 前任微信机器人 · 一键配置（macOS / Linux）
set -e
cd "$(dirname "$0")"

if ! command -v node >/dev/null 2>&1; then
  echo "[错误] 没有检测到 Node.js，请先安装：https://nodejs.org"
  exit 1
fi

node scripts/setup.mjs
