/**
 * 一键启动：检查配置 -> 检查人设 -> 启动微信机器人。
 *
 *   npm start       （或双击 start.bat）
 */
import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { pathToFileURL } from "node:url";

import { ROOT, EXES_DIR, ENV_FILE, BOT_ENTRY } from "./lib/paths.mjs";
import { loadEnv } from "./lib/env.mjs";
import { getLlmConfig } from "./lib/config.mjs";

const C = {
  b: (s) => `\x1b[1m${s}\x1b[0m`,
  g: (s) => `\x1b[32m${s}\x1b[0m`,
  y: (s) => `\x1b[33m${s}\x1b[0m`,
  r: (s) => `\x1b[31m${s}\x1b[0m`,
  d: (s) => `\x1b[2m${s}\x1b[0m`,
};

function findPersonaDirs() {
  try {
    return fs
      .readdirSync(EXES_DIR, { withFileTypes: true })
      .filter((d) => d.isDirectory())
      .map((d) => path.join(EXES_DIR, d.name))
      .filter(
        (d) =>
          fs.existsSync(path.join(d, "chat_rules.md")) ||
          fs.existsSync(path.join(d, "persona.md")),
      );
  } catch {
    return [];
  }
}

async function main() {
  loadEnv(ENV_FILE);
  let cfg = getLlmConfig();

  // 1) 没有 key -> 先跑配置向导
  if (!cfg.key) {
    console.log(C.y("  还没配置大模型 Key，先带你走一遍配置向导…\n"));
    const r = spawnSync(process.execPath, [path.join(ROOT, "scripts", "setup.mjs")], {
      stdio: "inherit",
      cwd: ROOT,
    });
    if (r.status !== 0) process.exit(r.status || 1);
    // 重新读取
    for (const k of Object.keys(process.env)) {
      if (k.startsWith("LLM_")) delete process.env[k];
    }
    loadEnv(ENV_FILE, { override: true });
    cfg = getLlmConfig();
    if (!cfg.key) {
      console.log(C.r("  仍未配置 Key，已退出。请运行 npm run setup。"));
      process.exit(1);
    }
    console.log("");
  }

  // 2) 人设检查
  const personas = findPersonaDirs();
  if (!personas.length) {
    console.log(C.y("  ⚠️  还没找到人设（exes/ 下为空）。"));
    console.log(C.d("     机器人会用内置兜底人设，效果一般。"));
    console.log(C.d("     建议先生成：npm run build -- --file 你的聊天记录.jsonl\n"));
  } else {
    const names = personas.map((p) => path.basename(p)).join("、");
    console.log(C.d(`  人设：${names}   模型：${cfg.model}`));
  }

  // 3) 启动
  console.log(C.b("\n  🚀 启动微信机器人（首次会输出二维码，用微信扫码登录）\n"));
  process.chdir(ROOT);
  await import(pathToFileURL(BOT_ENTRY).href);
}

main().catch((e) => {
  console.error(C.r("启动失败：" + (e?.stack || e)));
  process.exit(1);
});
