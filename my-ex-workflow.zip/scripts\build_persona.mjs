/**
 * jsonl 聊天记录 -> 人设三件套（chat_rules.md / persona.md / memories.md）
 *
 * 用法：
 *   node scripts/build_persona.mjs --file chat.jsonl [--name 小美] [--slug xiaomei]
 *                                  [--mine 我] [--profile "在一起三年 大学同学"]
 *                                  [--tags "ENFP 焦虑型 爱撒娇 翻脸"]
 *                                  [--only rules|persona|memories|analysis] [--force]
 *
 * 设计原则：口癖等一切"事实"只能来自本地语料的客观统计，模型只负责组织语言。
 */
import fs from "node:fs";
import path from "node:path";
import { pathToFileURL } from "node:url";

import { EXES_DIR, PROMPTS_DIR, ENV_FILE } from "./lib/paths.mjs";
import { loadEnv } from "./lib/env.mjs";
import { chat, stripFence } from "./lib/llm.mjs";
import { getLlmConfig } from "./lib/config.mjs";
import {
  readMessages,
  sortByTime,
  detectRoles,
  renderDialog,
  clampText,
} from "./lib/jsonl.mjs";
import { analyzeCorpus } from "./lib/stats.mjs";

const readPrompt = (name) => fs.readFileSync(path.join(PROMPTS_DIR, name), "utf-8");

function evenSample(arr, n) {
  if (arr.length <= n) return arr;
  const step = arr.length / n;
  return Array.from({ length: n }, (_, i) => arr[Math.floor(i * step)]);
}

function slugifyAscii(name) {
  return String(name)
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

/** 中文名 -> 拼音 slug（尽力而为，失败返回空串） */
async function pinyinSlug(name) {
  try {
    const { spawnSync } = await import("node:child_process");
    const code =
      "import sys\ntry:\n from pypinyin import lazy_pinyin\nexcept Exception:\n sys.exit(3)\nprint('-'.join(lazy_pinyin(sys.argv[1])))";
    const r = spawnSync("python", ["-c", code, name], { encoding: "utf-8" });
    if (r.status === 0 && r.stdout.trim()) return slugifyAscii(r.stdout.trim());
  } catch {}
  return "";
}

async function makeSlug(name) {
  const ascii = slugifyAscii(name);
  if (ascii) return ascii;
  const py = await pinyinSlug(name);
  if (py) return py;
  return "ex-" + Buffer.from(name).toString("hex").slice(0, 6);
}

function backupExisting(dir) {
  if (!fs.existsSync(dir)) return;
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const vdir = path.join(dir, "versions", stamp);
  fs.mkdirSync(vdir, { recursive: true });
  for (const f of ["chat_rules.md", "persona.md", "memories.md", "meta.json"]) {
    const p = path.join(dir, f);
    if (fs.existsSync(p)) fs.copyFileSync(p, path.join(vdir, f));
  }
}

/**
 * 执行完整生成。
 * @param {object} opts
 * @param {string} opts.file  jsonl 路径
 * @param {string} [opts.name]
 * @param {string} [opts.slug]
 * @param {string} [opts.mine]
 * @param {string} [opts.profile]
 * @param {string} [opts.tags]
 * @param {string} [opts.only]
 * @param {boolean} [opts.force]
 * @param {(msg:string)=>void} [opts.emit]
 * @returns {Promise<{slug:string, dir:string, target:string}>}
 */
export async function buildPersona(opts) {
  const emit = opts.emit || ((m) => process.stderr.write(m + "\n"));
  loadEnv(ENV_FILE);

  const abs = path.resolve(opts.file);
  if (!fs.existsSync(abs)) throw new Error(`找不到聊天记录文件：${abs}`);

  emit(`读取聊天记录：${abs}`);
  let msgs = readMessages(abs);
  if (!msgs.length) throw new Error("聊天记录解析为空，请检查 jsonl 格式（每行一个 JSON）。");
  msgs = sortByTime(msgs);

  const roles = detectRoles(msgs, { mine: opts.mine, target: opts.name });
  const target = (opts.name && opts.name.trim()) || roles.target;
  if (!target) throw new Error("无法识别对方昵称，请用 --name 指定。");
  const me = roles.me;
  emit(
    `识别到：对方「${target}」${roles.targetCount} 条，本人「${me}」${roles.meCount} 条，` +
      `共 ${msgs.length} 条`,
  );

  const targetTexts = msgs.filter((m) => m.sender === target).map((m) => m.content).filter(Boolean);
  const meTexts = msgs.filter((m) => m.sender === me).map((m) => m.content).filter(Boolean);
  if (targetTexts.length < 20) {
    emit(`⚠️  对方消息只有 ${targetTexts.length} 条，人设质量可能不稳，建议多喂一些记录。`);
  }

  const stats = analyzeCorpus(targetTexts, { meTexts });
  emit(`语料统计完成：平均 ${stats.avgLen} 字/条，${stats.shortPct}% 是超短句`);

  const targetBlock = clampText(evenSample(targetTexts, 600).join("\n"), 9000);
  const dialogBlock = clampText(renderDialog(msgs, { limit: 400 }), 9000);

  const slug = (opts.slug && slugifyAscii(opts.slug)) || (await makeSlug(target));
  const outDir = path.join(EXES_DIR, slug);
  const only = (opts.only || "").trim();
  if (!opts.force) backupExisting(outDir);
  fs.mkdirSync(outDir, { recursive: true });

  // 归档原始语料，方便以后追加/重跑
  const knowledgeDir = path.join(outDir, "knowledge", "chats");
  fs.mkdirSync(knowledgeDir, { recursive: true });
  fs.writeFileSync(path.join(knowledgeDir, `${target}_完整对话.txt`), renderDialog(msgs) + "\n", "utf-8");
  fs.writeFileSync(
    path.join(knowledgeDir, `${target}_仅对方消息.txt`),
    targetTexts.map((t, i) => `${i + 1}. ${t}`).join("\n") + "\n",
    "utf-8",
  );

  const analysisFile = path.join(outDir, ".analysis.md");
  let analysis = fs.existsSync(analysisFile) ? fs.readFileSync(analysisFile, "utf-8") : "";

  const needAnalysis = !only || only === "analysis" || !analysis;
  if (needAnalysis) {
    emit("① 分析性格与表达风格…");
    analysis = stripFence(
      await chat(
        [
          {
            role: "system",
            content:
              "你是一位资深的中文亲密关系与聊天人格分析师。你只依据提供的真实聊天记录做判断，" +
              "绝不脑补。分析要具体、可执行，并引用原话作为证据。",
          },
          {
            role: "user",
            content: `${readPrompt("persona_analyzer.md")}

---

## 已知信息
- 昵称/代号：${target}
- 用户补充：${opts.profile || "（无）"}
- 性格标签：${opts.tags || "（无）"}

## 客观统计（脚本从全量语料统计，可信，口癖以此为准）
${stats.text}

## 对方（${target}）说过的消息（抽样）
${targetBlock}

## 完整对话节选（含双方）
${dialogBlock}

---

请按 persona_analyzer.md 的维度与输出格式，给出结构化分析（中文）。`,
          },
        ],
        { max_tokens: 4000 },
      ),
    );
    fs.writeFileSync(analysisFile, analysis, "utf-8");
  }

  const callHim =
    (stats.address.find(([, c]) => c >= 5)?.[0]) || "你";

  const results = {};

  if (!only || only === "rules") {
    emit("② 生成聊天运行规则 chat_rules.md…");
    const personaSection = stripFence(
      await chat(
        [
          {
            role: "system",
            content:
              "你是顶级人设撰写师，专门把真实聊天记录萃取成开箱即用的聊天规则。" +
              "你严谨、不编造，只用证据说话。",
          },
          {
            role: "user",
            content: `${readPrompt("chat_rules.persona.md")}

---

## 客观统计（口癖的唯一来源）
${stats.text}

## 分析结果
${analysis}

## 真实对话节选（例子只能从这里摘取，不要改写）
${dialogBlock}

## 对方说过的消息（抽样）
${targetBlock}

---

现在输出 chat_rules.md 的「人设专属中段」：从「## 你真实的口癖」开始，到结尾「## 记住」结束。
直接输出 Markdown，不要代码围栏，不要任何额外说明。`,
          },
        ],
        { max_tokens: 4000 },
      ),
    );
    const universal = readPrompt("chat_rules.universal.md")
      .replaceAll("{{NAME}}", target)
      .replaceAll("{{CALL_HIM}}", callHim);
    const full = `${universal.trim()}\n\n---\n\n${personaSection.trim()}\n`;
    fs.writeFileSync(path.join(outDir, "chat_rules.md"), full, "utf-8");
    results.rules = full;
  }

  if (!only || only === "persona") {
    emit("③ 生成人物性格 persona.md…");
    const personaMd = stripFence(
      await chat(
        [
          {
            role: "system",
            content:
              "你是顶级人设撰写师。你只依据真实聊天记录与分析结果写人设，口癖等事实严禁编造。",
          },
          {
            role: "user",
            content: `${readPrompt("persona_builder.md")}

---

## 已知信息
- 名字：${target}
- 用户补充：${opts.profile || "（无）"}
- 性格标签：${opts.tags || "（无）"}
- 她称呼对方为：${callHim}

## 分析结果
${analysis}

## 客观统计（口癖以此为准，严禁生造）
${stats.text}

## 真实对话节选
${dialogBlock}

---

请直接输出 persona.md 全文（Markdown，从「# ${target} — Persona」开始），不要用代码围栏，不要额外说明。`,
          },
        ],
        { max_tokens: 5000 },
      ),
    );
    fs.writeFileSync(path.join(outDir, "persona.md"), personaMd + "\n", "utf-8");
    results.persona = personaMd;
  }

  if (!only || only === "memories") {
    emit("④ 生成共同记忆 memories.md…");
    const memoriesMd = stripFence(
      await chat(
        [
          {
            role: "system",
            content:
              "你是顶级关系记录者。你只把聊天记录里真实出现过的共同经历整理成记忆，" +
              "绝不虚构事件、日期或偏好。",
          },
          {
            role: "user",
            content: `${readPrompt("memories_analyzer.md")}

---

${readPrompt("memories_builder.md")}

---

## 已知信息
- 名字：${target}
- 用户补充：${opts.profile || "（无）"}
- 性格标签：${opts.tags || "（无）"}

## 分析结果
${analysis}

## 完整对话节选（记忆只能来自这里）
${dialogBlock}

## 对方说过的消息（抽样）
${targetBlock}

---

请直接输出 memories.md 全文（Markdown，从「# ${target} — 共同记忆」开始），不要用代码围栏。`,
          },
        ],
        { max_tokens: 4000 },
      ),
    );
    fs.writeFileSync(path.join(outDir, "memories.md"), memoriesMd + "\n", "utf-8");
    results.memories = memoriesMd;
  }

  const meta = {
    name: target,
    slug,
    profile: opts.profile || "",
    tags: opts.tags || "",
    call_him: callHim,
    source_file: abs,
    message_count: msgs.length,
    target_message_count: roles.targetCount,
    me: me,
    stats: {
      avg_len: stats.avgLen,
      short_pct: stats.shortPct,
      top_phrases: stats.phrases.slice(0, 15).map(([p, c]) => `${p}(${c})`),
    },
    llm: (() => {
      const c = getLlmConfig();
      return { base: c.base, model: c.model };
    })(),
    created_at: new Date().toISOString(),
  };
  fs.writeFileSync(path.join(outDir, "meta.json"), JSON.stringify(meta, null, 2), "utf-8");

  return { slug, dir: outDir, target };
}

// ── CLI ──────────────────────────────────────────────────────────────────────
function parseArgs(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith("--")) {
      const key = a.slice(2);
      const val = argv[i + 1] && !argv[i + 1].startsWith("--") ? argv[++i] : "true";
      out[key] = val;
    }
  }
  return out;
}

const isCli =
  process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href;

if (isCli) {
  const args = parseArgs(process.argv.slice(2));
  if (!args.file) {
    console.error(
      "用法：node scripts/build_persona.mjs --file chat.jsonl [--name 小美] [--slug xiaomei] [--mine 我]\n" +
        "      [--profile \"在一起三年 大学同学\"] [--tags \"ENFP 焦虑型 爱撒娇\"]\n" +
        "      [--only rules|persona|memories|analysis] [--force]",
    );
    process.exit(1);
  }
  try {
    const r = await buildPersona({
      file: args.file,
      name: args.name,
      slug: args.slug,
      mine: args.mine,
      profile: args.profile,
      tags: args.tags,
      only: args.only,
      force: args.force === "true",
      emit: (m) => console.error(m),
    });
    console.error("");
    console.error(`✅ 完成！人设已生成：exes/${r.slug}/`);
    console.error("下一步：运行 npm start 启动微信机器人。");
  } catch (e) {
    console.error("❌ 生成失败：" + e.message);
    process.exit(1);
  }
}
